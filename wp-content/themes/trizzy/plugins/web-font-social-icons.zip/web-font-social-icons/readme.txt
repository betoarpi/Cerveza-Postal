Web Fonts Social Icons WordPress Widget

It's simple plugin that displays social icons via shortcode or via widgets. You can customize color and sizes of icons.

Features:
- Easy to use
- Unlimited Color Options
- Multilanguage

Shortcode Usage:
Single icon
[pt_social_icon iconsize="small" type="single" service="wordpress" url="http://wordpress.org" ]

- Iconsize: small/standard - The small size is good for single icons in inline text
- Type: single/multi - If it's single it renders just as a anchor tag, if it's list, you need to wrap it in [pt_social_icons]
- Service: choose one of 30 icons
- URL: where the icon links

Widget Usage:
- Choose widget title. If no title is entered, it won't be displayed
- Icons - Add icons by selecting them from the list, you can then drag them as you wish, and drag outside the widget to remove.
- Background Color. Choose the background color of the icons
- Icon Color. Choose the color of the icons

Translation
	The plugin is fully localized.

Installation:
	Upload the plugin then activate it.
